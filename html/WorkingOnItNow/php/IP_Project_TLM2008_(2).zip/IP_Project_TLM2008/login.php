<!DOCTYPE html>
<html lang="en">
<?php include 'header.inc'?>
  

  <section id="loginsection">
        <form id="login"  method="#">
        <h3>Login Page</h3>
        LoginID or Email Address*<br><input type="text" name="LoginID" size="80" style="height:20px;" ><br><br>
        Password*<br><input type="text" name="passwd" size="60" style="height:20px;"/><br><br><br>
         <input type="button" value="LOGIN" style="height:20px; font-size:16px;"/>
         <p>Forgotten your password?</p>
        
        </form>
        </section>
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
</body>
<?php include 'footer.inc'?>
</html>	
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

