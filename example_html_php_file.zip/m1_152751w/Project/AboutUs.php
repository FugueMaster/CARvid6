<?php
	session_start();
	if (!isset($_SESSION['MM_Username']))
	{
	header("Location:Login.php");
    }
    $conn = mysqli_connect("localhost", "root", "","152751w" );
?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/AboutUs.css">
    <title></title>

    </head>
    <body>

    <div id="wrapper">
    <header>
    <div id="logo">
        <a href="Homepage.php" title="HomePage"><img src="images/LOGO.jpg"/></a>
     </div>

    <form id="hform">
    SEARCH: <input type="text" name="search" id="searchbar" min="0" max="50"/>
            <input type="button" value="GO" style="height:18px; font-size:14px;"/>

    </form>
        <nav id="mainNav">
            <ul id="test">
            <li><a href="Login.php" title="Login">LOGIN  |</a></li>
			<li><a href="Register.php" title="Register">REGISTER</a></li>
            </ul>
        </nav>

    <div id="shoppingcart">
    <a href="ShowCart.php" title="ShoppingCartPage"><img src="images/Shoppingcart.png"/></a>
    </div>
        </header>
        <section id="section1">
         <p><a href="Logout.php">Log Out</a></p>
        <nav id="subNav">
            <ul>

          <p>MUSIC CATEGORY</p>

          <li><a href="MusicGenres.php" title="Genre"><img src="images/ArrowNav.png">Genre</a></li>
          <li><a href="MusicGenres.php" title="Music"><img src="images/ArrowNav.png">Music</a></li>
          <li><a href="orderhistory.php" title="deliverydetails"><img src="images/ArrowNav.png">
                 Delivery Details</a></li>
          <li><a href="ShoppingCartPage.html" title="Pre-Orders"><img src="images/ArrowNav.png">Pre-Orders</a></li>
          <p>NEW ARRIVALS</p>
          <li><a href="MusicGenres.php" title="FeaturedProducts"><img src="images/ArrowNav.png">Featured Products</a></li>
          <li><a href="BestSellers.php" title="TopSellingProducts"><img src="images/ArrowNav.png">
                Top Selling Products</a></li>
          <p>BROWSE BY</p>
          <li><a href="ArtistList.html" title="Artists"><img src="images/ArrowNav.png">Artists</a></li>
          <li><a href=".html" title="Recent Releases"><img src="images/ArrowNav.png">Recent Releases<br>
                &lt;BY MONTH&gt;</a></li>
            </ul>
            </nav>
             <article id="AboutUs">

			        <h1>About Us</h1>
			        <p>RY, is a recently estalished music CD Shop in 2013 and we have imported CD
			<br>deliveries mostly in or region base in Singapore. We do offer certain CDs at a
			<br>lower rate of prices and all or available selling products ranges from popular
			<br>pop/rock songs to well-known Christian songs.

			<br>There are about 100000 CD songs available. We have a variety of music
			<br>categories namely Pop, rock, Jazz/Contemporary, Country/folk, Classical and lastly
			<br>Praise & Worship songs.

			<br>Should you have any queries, simply drop us an email @RYMusicStoreOnline.sg or call us at
			<br>9613 7982 and we�ll get back to you as soon as possible.</p>
			        </article>
        </section>
             <footer>
				            <nav id="footerNav">
				            <ul>
				            <li><a href="AboutUs.php" title="AboutUs">About Us</a></li>
				            <li><a href="ContactUs.php" title="SiteFeedback">Site Feedback</a></li>
				            <li><a href="showCart.php" title="YourOrders">Your Orders</a></li>
				            <li><a href="showTransact.php" title="OrderHistory">Order History</a></li>
				            <li><a href="Help.php" title="Help">Help</a></li>
				            <li><a href="ContactUs.php" title="Contact Us">Contact Us</a></li><br>
				             <p>2016�Copyrights RY Music CD Online Store All Rights Reserved</p>

				            </ul>
				            </nav>
				            <div id="copyright">

				            </div>
				            </footer>


				            </div>

				        </body>

</html>