<?php
session_start();
if (!isset($_SESSION['MM_Username']))
{
header("Location:Login.php");
}
$conn = mysqli_connect("localhost", "root", "","152751w" );

$cidToUpdate = $_POST['productID'];
$sql="DELETE from orderdetails WHERE ProductID = '$cidToUpdate'";


$delete = mysqli_query($conn, $sql);
header("Location:ShowCart.php");

?>

