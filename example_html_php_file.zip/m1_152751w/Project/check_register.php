<?php


$f = $_POST['firstname'];
$l = $_POST['lastname'];
$a = $_POST['address'];
$u = $_POST['username'];
$c = $_POST['code'];
$p = $_POST['passwd'];


$conn=mysqli_connect("localhost", "root", "", "152751w");

$insert_sql="insert into user (FirstName,LastName,Address,Username,PostalCode,pass) values ('$f','$l','$a','$u','$c','$p');";
$result=mysqli_query($conn , $insert_sql);
if ($result==1)
{
    header("Location:Login.php?ok=1");
}
else
{
    header("Location:Register.php?error=2");
}

?>
