<?php
session_start();
if (!isset($_SESSION['MM_Username']))
{
header("Location:Login.php");
}
$conn = mysqli_connect("localhost", "root", "","152751w" );
// update cart set qty=2 where id=5
$cidToUpdate = $_POST['productID'];
$newQty = $_POST['nqty'];

$sql = "UPDATE orderdetails SET Quantity = '$newQty' where ProductID = '$cidToUpdate' ";
$update = mysqli_query($conn, $sql);
echo $update;

header("Location:ShowCart.php");
?>
